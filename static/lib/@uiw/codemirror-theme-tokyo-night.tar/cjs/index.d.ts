import { type CreateThemeOptions } from '@uiw/codemirror-themes';
export declare const defaultSettingsTokyoNight: CreateThemeOptions['settings'];
export declare const tokyoNightStyle: CreateThemeOptions['styles'];
export declare const tokyoNightInit: (options?: Partial<CreateThemeOptions>) => import("@codemirror/state").Extension;
export declare const tokyoNight: import("@codemirror/state").Extension;
