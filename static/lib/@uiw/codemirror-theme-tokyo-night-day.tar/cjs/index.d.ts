import { type CreateThemeOptions } from '@uiw/codemirror-themes';
export declare const defaultSettingsTokyoNightDay: CreateThemeOptions['settings'];
export declare const tokyoNightDayStyle: CreateThemeOptions['styles'];
export declare const tokyoNightDayInit: (options?: Partial<CreateThemeOptions>) => import("@codemirror/state").Extension;
export declare const tokyoNightDay: import("@codemirror/state").Extension;
